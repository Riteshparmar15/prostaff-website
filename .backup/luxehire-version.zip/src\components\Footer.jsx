import { Linkedin, Mail } from 'lucide-react';
import { footer } from '../data/content';
import Logo from './ui/Logo';
import Reveal, { stagger } from './ui/Reveal';

const iconBtn =
  'flex h-10 w-10 items-center justify-center rounded-full border border-ivory/15 text-mist transition-colors duration-300 hover:border-gold hover:bg-gold/10 hover:text-gold-light';

export default function Footer() {
  return (
    <footer className="surface-grain border-t border-gold/20 bg-onyx">
      <div className="container-luxe py-16">
        <div className="flex flex-col items-center gap-10 lg:flex-row lg:justify-between">
          <Reveal delay={stagger(0)}>
            <Logo />
          </Reveal>

          <Reveal as="nav" delay={stagger(1)} aria-label="Footer" className="max-w-2xl">
            <ul className="flex flex-wrap justify-center gap-x-6 gap-y-3">
              {footer.links.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-micro font-medium uppercase tracking-btn text-mist transition-colors duration-300 hover:text-gold-light"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={stagger(2)} className="flex gap-3">
            <a href={footer.social.linkedin} target="_blank" rel="noopener noreferrer" aria-label="LuxeHire on LinkedIn" className={iconBtn}>
              <Linkedin aria-hidden="true" strokeWidth={1.5} className="h-4 w-4" />
            </a>
            <a href={`mailto:${footer.social.email}`} aria-label="Email LuxeHire" className={iconBtn}>
              <Mail aria-hidden="true" strokeWidth={1.5} className="h-4 w-4" />
            </a>
          </Reveal>
        </div>

        <Reveal delay={stagger(3)} className="mt-12 border-t border-ivory/10 pt-8 text-center text-xs leading-relaxed text-mist">
          <p>{footer.copyright}</p>
          <p className="mt-1">
            {footer.operatedBy}
            <a href={`mailto:${footer.privacyEmail}`} className="underline-offset-4 hover:text-gold-light hover:underline">
              {footer.privacyEmail}
            </a>
          </p>
        </Reveal>
      </div>
    </footer>
  );
}

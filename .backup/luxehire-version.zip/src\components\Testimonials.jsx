import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
import { testimonials } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import Reveal, { HOVER_SPRING, stagger } from './ui/Reveal';
import useReducedMotion from '../hooks/useReducedMotion';

export default function Testimonials() {
  const reduced = useReducedMotion();

  return (
    <section id="testimonials" aria-labelledby="testimonials-title" className="surface-grain section-pad bg-onyx">
      {/* Soft gold bloom behind the cards */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/3 -z-10 h-96 w-[56rem] max-w-full -translate-x-1/2 rounded-full bg-gold/10 blur-3xl"
      />

      <div className="container-luxe">
        <SectionHeading id="testimonials-title" tone="dark" eyebrow={testimonials.eyebrow} title={testimonials.title} />

        <div className="mx-auto mt-16 grid max-w-grid gap-6 lg:grid-cols-2">
          {testimonials.items.map((t, i) => (
            <Reveal key={t.name} delay={stagger(i)} className="h-full">
              <motion.figure
                whileHover={reduced ? undefined : { y: -6 }}
                transition={HOVER_SPRING}
                className="group flex h-full flex-col rounded-luxe border border-ivory/10 bg-ivory/[0.03] p-8 backdrop-blur-sm transition-colors duration-500 ease-luxe hover:border-gold/60 md:p-10"
              >
                <Quote aria-hidden="true" strokeWidth={1.25} className="h-10 w-10 text-gold" />

                <blockquote className="mt-6 flex-1 font-serif text-lg italic leading-relaxed text-ivory/90">
                  <p>“{t.quote}”</p>
                </blockquote>

                <div aria-hidden="true" className="my-8 h-px w-full bg-gradient-to-r from-gold/60 via-ivory/10 to-transparent" />

                <figcaption>
                  <p className="font-sans text-body-sm font-medium text-ivory">{t.name}</p>
                  <p className="mt-1 text-sm text-mist">{t.role}</p>
                </figcaption>
              </motion.figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

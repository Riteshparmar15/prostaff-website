/**
 * All LuxeHire site copy lives here. Components are purely presentational
 * and read from these objects, so copy edits never require touching JSX.
 */
import {
  Award,
  Briefcase,
  Building2,
  Clock,
  Compass,
  EyeOff,
  Globe,
  Heart,
  Search,
  Shield,
  Star,
  TrendingUp,
  Users,
} from 'lucide-react';

export const brand = {
  name: 'LuxeHire',
  logoItalic: 'Luxe',
  logoRegular: 'Hire',
};

/* ------------------------------------------------------------------ */
/*  Navigation                                                         */
/* ------------------------------------------------------------------ */
export const nav = {
  links: [
    { label: 'Home', href: '#home' },
    { label: 'For Brands', href: '#for-brands' },
    { label: 'For Candidates', href: '#for-talent' },
    { label: 'Who We Are', href: '#founders' },
    { label: 'Contact', href: '#contact' },
  ],
  cta: { label: 'Hire With Us', href: '#contact' },
};

/* ------------------------------------------------------------------ */
/*  Hero                                                               */
/* ------------------------------------------------------------------ */
export const hero = {
  eyebrow: 'Boutique Luxury Recruitment',
  // Each inner array is one visual line; `accent` segments render in gold italic.
  headingLines: [
    [{ text: 'Curating Talent for the' }],
    [{ text: "World's Finest", accent: true }, { text: ' Brands' }],
  ],
  subheading:
    'Connecting iconic luxury brands with exceptional professionals across fashion, retail, jewelry, and lifestyle.',
  primaryCta: { label: 'Hire With Us', href: '#contact' },
  secondaryCta: { label: 'Explore Opportunities', href: '#for-talent' },
  image: {
    webp: '/images/hero.webp',
    webpMobile: '/images/hero-mobile.webp',
    jpg: '/images/hero.jpg',
    alt: 'Softly lit luxury boutique with cream and champagne garments on gold rails',
    width: 1920,
    height: 1080,
  },
};

/* ------------------------------------------------------------------ */
/*  Brand marquee                                                      */
/* ------------------------------------------------------------------ */
export const brands = {
  eyebrow: 'Trusted by Leading Brands',
  // `style` maps to a wordmark treatment in BrandMarquee.jsx.
  // Swap for `logo: '/images/brands/xyz.svg'` once official files are supplied.
  items: [
    { name: 'GOOSE', style: 'sansBold' },
    { name: 'VALENTINO', style: 'serifWide' },
    { name: 'ABU JANI SANDEEP KHOSLA', style: 'serifStacked' },
    { name: 'LE MILL', style: 'serifItalic' },
    { name: 'BALENCIAGA', style: 'sansCondensed' },
    { name: 'MANISH MALHOTRA', style: 'serifCaps' },
  ],
};

/* ------------------------------------------------------------------ */
/*  Stats                                                              */
/* ------------------------------------------------------------------ */
export const stats = [
  { value: 200, suffix: '+', label: 'Successful Placements' },
  { value: 5, suffix: '+', label: 'Years of Experience' },
  { value: 50, suffix: '+', label: 'Luxury Brands Served' },
  { value: 95, suffix: '%', label: 'Client Retention Rate' },
];

/* ------------------------------------------------------------------ */
/*  Why LuxeHire                                                       */
/* ------------------------------------------------------------------ */
export const why = {
  eyebrow: 'Why LuxeHire',
  title: 'The Art of Luxury Recruitment',
  description:
    'We recognise that luxury recruitment is an art form. Our boutique philosophy combines profound industry insight with meticulous attention, ensuring seamless alignment of culture, capability, and vision.',
  features: [
    {
      icon: Heart,
      title: 'Boutique Approach',
      description: 'A personalised, high-touch service tailored to the distinctive needs of luxury brands.',
    },
    {
      icon: Users,
      title: 'Elite Talent Network',
      description: 'Exclusive access to a meticulously curated network of exceptional luxury professionals.',
    },
    {
      icon: Shield,
      title: 'Discretion & Excellence',
      description: 'Confidential partnerships that honour your prestige and exacting standards.',
    },
    {
      icon: Globe,
      title: 'Global Presence',
      description: 'Serving premier luxury markets worldwide with deep regional expertise.',
    },
  ],
};

/* ------------------------------------------------------------------ */
/*  For Brands                                                         */
/* ------------------------------------------------------------------ */
export const forBrands = {
  eyebrow: 'For Brands',
  title: 'Building Exceptional Leadership Teams',
  description:
    'Whether you are expanding into new territories, assembling a leadership team, or securing a pivotal hire, we deliver candidates who exemplify luxury excellence.',
  features: [
    {
      icon: Search,
      title: 'Precision Executive Search',
      description:
        "We identify and engage distinguished candidates who embody your brand's culture and strategic vision.",
    },
    {
      icon: Users,
      title: 'Exclusive Talent Access',
      description:
        'Gain entry to our private network of pre-qualified luxury professionals at all leadership tiers.',
    },
    {
      icon: Shield,
      title: 'Absolute Discretion',
      description: "Confidential engagements that safeguard your brand's reputation and competitive position.",
    },
    {
      icon: Clock,
      title: 'Expedited Delivery',
      description: 'A refined process that presents exceptional shortlists within weeks, not months.',
    },
    {
      icon: Award,
      title: 'Performance Assurance',
      description:
        'Our industry-leading placement guarantee protects your investment and ensures lasting success.',
    },
    {
      icon: Building2,
      title: 'Brand Immersion',
      description: 'We invest in understanding your brand essence to ensure impeccable cultural alignment.',
    },
  ],
  cta: { label: 'Discuss Your Requirements', href: '#contact' },
};

/* ------------------------------------------------------------------ */
/*  For Talent                                                         */
/* ------------------------------------------------------------------ */
export const forTalent = {
  eyebrow: 'For Talent',
  title: 'Elevate Your Career in Luxury',
  description:
    "Whether you are a seasoned executive or an emerging professional, we connect ambitious professionals with extraordinary opportunities at the world's most coveted brands.",
  features: [
    {
      icon: Briefcase,
      title: 'Exclusive Opportunities',
      description:
        'Access confidential positions with prestigious maisons that are never publicly advertised.',
    },
    {
      icon: TrendingUp,
      title: 'Strategic Career Growth',
      description:
        'We focus on roles offering meaningful advancement aligned with your long-term aspirations.',
    },
    {
      icon: Compass,
      title: 'Bespoke Guidance',
      description:
        'Receive tailored counsel on positioning, interview preparation, and compensation negotiation.',
    },
    {
      icon: EyeOff,
      title: 'Absolute Confidentiality',
      description:
        'Your career exploration remains entirely private—we never share details without your explicit consent.',
    },
    {
      icon: Star,
      title: 'Sector Expertise',
      description:
        'Benefit from our profound understanding of luxury retail, fashion, and premium lifestyle sectors.',
    },
    {
      icon: Globe,
      title: 'International Reach',
      description:
        'Connect with exceptional opportunities across India, the Middle East, Europe, and beyond.',
    },
  ],
  cta: { label: 'Submit Your Profile', href: '#contact' },
};

/* ------------------------------------------------------------------ */
/*  Testimonials                                                       */
/* ------------------------------------------------------------------ */
export const testimonials = {
  eyebrow: 'Client Stories',
  title: 'What Our Clients Say',
  items: [
    {
      quote:
        'Working with LuxeHire has been a seamless experience. Their deep understanding of hiring requirements and ability to deliver precisely aligned profiles sets them apart. The end-to-end recruitment process is handled with clarity, efficiency, and professionalism. Consistent responsiveness and a strong focus on quality make LuxeHire a trusted partner for luxury retail.',
      name: 'Tavishi Suneja',
      role: 'HR at Reliance Brands Ltd.',
    },
    {
      quote:
        'It has been a pleasure partnering with LuxeHire over the past two years. Their expertise in luxury retail and corporate recruitment is truly top-tier. With a deep understanding of the global market and a consistent ability to deliver high-quality talent, LuxeHire has proven to be a valuable hiring partner. I highly recommend LuxeHire to brands seeking a strategic, reliable recruitment partner to build high-performing teams.',
      name: 'Kajal Tanwar',
      role: 'Reliance Brands Limited | Bestseller Retail India | Clients Group of Hotels and Resorts',
    },
  ],
};

/* ------------------------------------------------------------------ */
/*  Founders                                                           */
/* ------------------------------------------------------------------ */
export const founders = {
  eyebrow: 'Our Leadership',
  title: 'The Founders of LuxeHire',
  description:
    'LuxeHire was founded by industry veterans who intimately understand the nuances of luxury talent acquisition. We unite deep market expertise with an authentic passion for connecting exceptional individuals with iconic brands.',
  people: [
    {
      name: 'Pranshu Tiwari',
      role: 'Founder',
      image: '/images/pranshu.jpg',
      bio: 'Pranshu Tiwari brings a strategic, brand-first approach to luxury talent acquisition, working across fashion, jewellery, watches, beauty, and lifestyle maisons. With experience in global market hiring and brand partnerships, he focuses on aligning top-tier talent with long-term brand vision. Pranshu is known for building strong leadership pipelines and fostering meaningful collaborations within the luxury ecosystem.',
      email: 'hello@luxehire.in',
      linkedin: 'https://www.linkedin.com/',
    },
    {
      name: 'Romil Trivedi',
      role: 'Founder & CEO',
      image: '/images/romil.jpg',
      bio: 'Romil Trivedi is a luxury recruitment specialist with expertise in leadership and frontline hiring across global premium and luxury retail markets. With a strong understanding of brand DNA, customer experience, and retail operations, he partners with international luxury maisons and high-growth brands worldwide to deliver exceptional talent with speed, precision, and quality. Romil is recognised for his global network, market insight, and commitment to excellence.',
      email: 'hello@luxehire.in',
      linkedin: 'https://www.linkedin.com/',
    },
  ],
};

/* ------------------------------------------------------------------ */
/*  Contact                                                            */
/* ------------------------------------------------------------------ */
export const contact = {
  eyebrow: 'Begin Your Journey',
  title: "Let's Start a Conversation",
  description:
    'Whether you represent a luxury brand seeking exceptional talent or are a professional exploring new horizons, we would be delighted to connect.',
  details: {
    title: 'Company Details',
    email: 'hello@luxehire.in',
    phones: [
      { display: '+91 6355 523 076', tel: '+916355523076' },
      { display: '+91 6351 214 414', tel: '+916351214414' },
    ],
    address: '410, Nilamber Primero, Bhayli Vasna Road, Vadodara, Gujarat 391410, India',
    mapUrl:
      'https://www.google.com/maps/search/?api=1&query=410+Nilamber+Primero+Bhayli+Vasna+Road+Vadodara+Gujarat+391410',
  },
  form: {
    name: 'Your Name',
    email: 'Email Address',
    phone: 'Phone (optional)',
    phonePrefix: '+91',
    phoneHelper: 'Include country code, e.g. +91 98765 43210',
    subject: 'Subject',
    message: 'How Can We Help?',
    consentBefore:
      'I consent to LuxeHire, operated by Devlospx Technologies Pvt. Ltd., processing my personal data to respond to my enquiry, in accordance with the LuxeHire ',
    consentLink: { label: 'Privacy Policy', href: '/privacy-policy' },
    consentAfter: '.',
    submit: 'Send',
    sending: 'Sending…',
    success: "Thank you — we'll be in touch shortly.",
    failure: 'Something went wrong. Please try again or email hello@luxehire.in.',
    errors: {
      name: 'Please enter your name.',
      email: 'Please enter your email address.',
      emailInvalid: 'Please enter a valid email address.',
      message: 'Please tell us how we can help.',
      consent: 'Please provide your consent so we can respond.',
    },
    endpoint: '/api/contact',
  },
};

/* ------------------------------------------------------------------ */
/*  Footer                                                             */
/* ------------------------------------------------------------------ */
export const footer = {
  links: [
    { label: 'About', href: '#why' },
    { label: 'For Brands', href: '#for-brands' },
    { label: 'For Talent', href: '#for-talent' },
    { label: 'Contact', href: '#contact' },
    { label: 'Who We Are', href: '#founders' },
    { label: 'Privacy Policy', href: '/privacy-policy' },
    { label: 'Data Protection', href: '/data-protection' },
    { label: 'Cookie Policy', href: '/cookie-policy' },
    { label: 'Terms of Service', href: '/terms-of-service' },
  ],
  social: {
    linkedin: 'https://www.linkedin.com/',
    email: 'hello@luxehire.in',
  },
  copyright: '© 2026 LuxeHire. All rights reserved.',
  operatedBy: 'Operated by Devlospx Technologies Pvt. Ltd. · Privacy: ',
  privacyEmail: 'privacy@luxehire.in',
};

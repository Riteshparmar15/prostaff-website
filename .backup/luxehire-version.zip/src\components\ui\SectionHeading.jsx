import Reveal, { stagger } from './Reveal';

/**
 * Eyebrow + H2 + intro paragraph, each revealed in sequence.
 * `tone="dark"` swaps to light text for onyx/midnight sections.
 */
export default function SectionHeading({ id, eyebrow, title, description, tone = 'light', className = '' }) {
  const dark = tone === 'dark';

  return (
    <div className={`mx-auto max-w-prose text-center ${className}`}>
      <Reveal as="p" delay={stagger(0)} className={`eyebrow ${dark ? 'text-gold-light' : 'text-gold-deep'}`}>
        {eyebrow}
      </Reveal>

      <Reveal
        as="h2"
        id={id}
        delay={stagger(1)}
        className={`mt-4 text-h2 font-medium ${dark ? 'text-ivory' : 'text-ink'}`}
      >
        {title}
      </Reveal>

      <Reveal aria-hidden="true" delay={stagger(2)} className="mx-auto mt-6 h-px w-12 bg-gold" />

      {description && (
        <Reveal as="p" delay={stagger(3)} className={`mt-6 text-body ${dark ? 'text-mist' : 'text-stone'}`}>
          {description}
        </Reveal>
      )}
    </div>
  );
}

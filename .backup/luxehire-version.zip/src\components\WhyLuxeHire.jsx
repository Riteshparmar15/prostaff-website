import { why } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import FeatureCard from './ui/FeatureCard';
import { stagger } from './ui/Reveal';

export default function WhyLuxeHire() {
  return (
    <section id="why" aria-labelledby="why-title" className="surface-glow section-pad bg-ivory">
      <div className="container-luxe">
        <SectionHeading id="why-title" eyebrow={why.eyebrow} title={why.title} description={why.description} />

        <div className="mx-auto mt-16 grid max-w-grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {why.features.map((f, i) => (
            <FeatureCard key={f.title} {...f} align="center" delay={stagger(i)} />
          ))}
        </div>
      </div>
    </section>
  );
}

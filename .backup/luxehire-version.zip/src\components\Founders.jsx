import { useState } from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Mail } from 'lucide-react';
import { founders } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import Reveal, { HOVER_SPRING, stagger } from './ui/Reveal';
import useReducedMotion from '../hooks/useReducedMotion';

const PORTRAIT_WIDTH = 800;
const PORTRAIT_HEIGHT = 1000;

const initials = (name) =>
  name
    .split(' ')
    .map((n) => n[0])
    .join('');

function Portrait({ person }) {
  const [failed, setFailed] = useState(false);

  return (
    <div className="relative aspect-[4/5] overflow-hidden bg-midnight">
      {failed ? (
        // Elegant monogram until the client's photo is dropped into /public/images
        <div className="surface-grain flex h-full w-full items-center justify-center bg-midnight">
          <span className="font-serif text-7xl italic text-gold-light/80">{initials(person.name)}</span>
        </div>
      ) : (
        <img
          src={person.image}
          alt={`Portrait of ${person.name}, ${person.role} of LuxeHire`}
          width={PORTRAIT_WIDTH}
          height={PORTRAIT_HEIGHT}
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
          className="h-full w-full object-cover object-top transition-transform duration-700 ease-luxe group-hover:scale-104"
        />
      )}
      <div aria-hidden="true" className="absolute inset-0 bg-portrait-fade" />
      <div aria-hidden="true" className="absolute inset-3 border border-gold-light/30" />
    </div>
  );
}

const IconLink = ({ href, label, children, external }) => (
  <a
    href={href}
    aria-label={label}
    {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
    className="flex h-10 w-10 items-center justify-center rounded-full border border-sand text-stone transition-colors duration-300 hover:border-gold hover:bg-gold/10 hover:text-gold-deep"
  >
    {children}
  </a>
);

export default function Founders() {
  const reduced = useReducedMotion();

  return (
    <section id="founders" aria-labelledby="founders-title" className="surface-glow section-pad bg-champagne">
      <div className="container-luxe">
        <SectionHeading
          id="founders-title"
          eyebrow={founders.eyebrow}
          title={founders.title}
          description={founders.description}
        />

        <div className="mx-auto mt-16 grid max-w-founders gap-8 md:grid-cols-2">
          {founders.people.map((person, i) => (
            <Reveal key={person.name} delay={stagger(i)} className="h-full">
              <motion.article
                whileHover={reduced ? undefined : { y: -6 }}
                transition={HOVER_SPRING}
                className="group flex h-full flex-col overflow-hidden rounded-luxe border border-sand bg-white/70 shadow-card transition-[border-color,box-shadow] duration-500 ease-luxe hover:border-gold hover:shadow-card-hover"
              >
                <Portrait person={person} />

                <div className="flex flex-1 flex-col p-8">
                  <h3 className="text-2xl font-medium text-ink">{person.name}</h3>
                  <p className="eyebrow mt-2 text-gold-deep">{person.role}</p>
                  <p className="mt-5 flex-1 text-body-sm text-stone">{person.bio}</p>

                  <div className="mt-6 flex gap-3">
                    <IconLink href={`mailto:${person.email}`} label={`Email ${person.name}`}>
                      <Mail aria-hidden="true" strokeWidth={1.5} className="h-4 w-4" />
                    </IconLink>
                    <IconLink href={person.linkedin} label={`${person.name} on LinkedIn`} external>
                      <Linkedin aria-hidden="true" strokeWidth={1.5} className="h-4 w-4" />
                    </IconLink>
                  </div>
                </div>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'framer-motion';
import Reveal, { HOVER_SPRING } from './Reveal';
import useReducedMotion from '../../hooks/useReducedMotion';

/**
 * Glassy ivory card with an outlined icon circle.
 * `align="center"` for Why LuxeHire, `align="left"` for the service grids.
 */
export default function FeatureCard({ icon: Icon, title, description, align = 'left', delay = 0 }) {
  const reduced = useReducedMotion();
  const centered = align === 'center';

  return (
    <Reveal delay={delay} className="h-full">
      <motion.article
        whileHover={reduced ? undefined : { y: -6 }}
        transition={HOVER_SPRING}
        className={[
          'group h-full rounded-luxe border border-sand bg-white/70 p-8 shadow-card backdrop-blur-sm',
          'transition-[border-color,box-shadow] duration-500 ease-luxe hover:border-gold hover:shadow-card-hover',
          centered ? 'text-center' : 'text-left',
        ].join(' ')}
      >
        <div
          className={[
            'flex items-center justify-center rounded-full border border-gold/60 text-gold',
            'transition-colors duration-500 ease-luxe group-hover:bg-gold/10 group-hover:border-gold',
            centered ? 'mx-auto h-16 w-16' : 'h-12 w-12',
          ].join(' ')}
        >
          <Icon aria-hidden="true" strokeWidth={1.25} className={centered ? 'h-6 w-6' : 'h-5 w-5'} />
        </div>

        <h3 className="mt-6 text-card-title font-medium text-ink">{title}</h3>
        <p className="mt-3 text-body-sm text-stone">{description}</p>
      </motion.article>
    </Reveal>
  );
}

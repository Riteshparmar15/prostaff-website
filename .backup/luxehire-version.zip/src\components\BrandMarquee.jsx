import { useEffect, useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { brands } from '../data/content';
import Reveal from './ui/Reveal';
import useReducedMotion from '../hooks/useReducedMotion';

const NUDGE_PX = 260;
const NUDGE_MS = 550;

/** Typographic stand-ins for each brand's wordmark. */
const WORDMARK_STYLES = {
  sansBold: 'font-sans text-2xl font-semibold tracking-widest',
  serifWide: 'font-serif text-2xl tracking-wordmark',
  serifStacked: 'block max-w-[11rem] text-center font-serif text-sm leading-snug tracking-widest',
  serifItalic: 'font-serif text-2xl italic tracking-wide',
  sansCondensed: 'font-sans text-2xl font-semibold tracking-tight',
  serifCaps: 'font-serif text-lg tracking-wordmark',
};

function Wordmark({ item }) {
  return (
    <span
      className={[
        'inline-flex items-center whitespace-normal text-ink opacity-55 grayscale transition duration-500 ease-luxe',
        'hover:scale-106 hover:opacity-100 hover:grayscale-0',
        WORDMARK_STYLES[item.style],
      ].join(' ')}
    >
      {item.name}
    </span>
  );
}

function BrandList({ hidden = false, wrap = false }) {
  return (
    <ul
      className={`flex items-center ${wrap ? 'flex-wrap justify-center' : 'shrink-0'}`}
      aria-hidden={hidden || undefined}
    >
      {brands.items.map((item) => (
        <li key={item.name} className="flex h-20 shrink-0 items-center px-8 md:px-12">
          <Wordmark item={item} />
        </li>
      ))}
    </ul>
  );
}

const ArrowButton = ({ direction, onClick }) => {
  const Icon = direction === 'prev' ? ChevronLeft : ChevronRight;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={direction === 'prev' ? 'Scroll brands back' : 'Scroll brands forward'}
      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-sand bg-white/80 text-ink shadow-card transition-colors duration-300 hover:border-gold hover:text-gold-deep"
    >
      <Icon aria-hidden="true" strokeWidth={1.5} className="h-4 w-4" />
    </button>
  );
};

export default function BrandMarquee() {
  const reduced = useReducedMotion();
  const trackRef = useRef(null);
  const rafRef = useRef(0);
  const [held, setHeld] = useState(false);

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  /**
   * Shift the running CSS marquee by NUDGE_PX in either direction by easing
   * the animation's currentTime. Because the keyframes loop over exactly one
   * copy of the list, wrapping the time keeps the loop seamless and autoplay
   * simply continues from the new position.
   */
  const nudge = (dir) => {
    const track = trackRef.current;
    const anim = track?.getAnimations?.()[0];
    if (!anim) return;

    const period = track.scrollWidth / 2;
    const duration = Number(anim.effect.getTiming().duration);
    const delta = (NUDGE_PX / period) * duration * dir;
    const from = Number(anim.currentTime) || 0;
    const t0 = performance.now();

    cancelAnimationFrame(rafRef.current);
    const tick = (now) => {
      const p = Math.min(1, (now - t0) / NUDGE_MS);
      const eased = 1 - (1 - p) ** 3;
      const t = from + delta * eased;
      anim.currentTime = ((t % duration) + duration) % duration;
      if (p < 1) rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
  };

  const holdHandlers = {
    onPointerDown: (e) => e.pointerType === 'touch' && setHeld(true),
    onPointerUp: () => setHeld(false),
    onPointerCancel: () => setHeld(false),
    onPointerLeave: () => setHeld(false),
  };

  return (
    <section aria-labelledby="brands-title" className="surface-glow bg-ivory py-14 md:py-16">
      <div className="container-luxe">
        <Reveal as="p" id="brands-title" className="eyebrow text-center text-gold-deep">
          {brands.eyebrow}
        </Reveal>

        <Reveal delay={0.1} className="mt-8 flex items-center gap-3 md:gap-5">
          {!reduced && <ArrowButton direction="prev" onClick={() => nudge(-1)} />}

          {reduced ? (
            <div className="flex-1">
              <BrandList wrap />
            </div>
          ) : (
            <div
              className={`marquee min-w-0 flex-1 overflow-hidden ${held ? 'is-held' : ''}`}
              tabIndex={0}
              role="region"
              aria-label="Brands we work with (hover or focus to pause)"
              {...holdHandlers}
            >
              <div ref={trackRef} className="track flex w-max">
                <BrandList />
                <BrandList hidden />
              </div>
            </div>
          )}

          {!reduced && <ArrowButton direction="next" onClick={() => nudge(1)} />}
        </Reveal>
      </div>
    </section>
  );
}

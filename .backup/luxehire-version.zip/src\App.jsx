import { MotionConfig } from 'framer-motion';
import Header from './components/Header';
import Hero from './components/Hero';
import BrandMarquee from './components/BrandMarquee';
import Stats from './components/Stats';
import WhyLuxeHire from './components/WhyLuxeHire';
import ForBrands from './components/ForBrands';
import ForTalent from './components/ForTalent';
import Testimonials from './components/Testimonials';
import Founders from './components/Founders';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:bg-onyx focus:px-4 focus:py-2 focus:text-ivory"
      >
        Skip to content
      </a>

      <Header />

      <main id="main">
        <Hero />
        <BrandMarquee />
        <Stats />
        <WhyLuxeHire />
        <ForBrands />
        <ForTalent />
        <Testimonials />
        <Founders />
        <Contact />
      </main>

      <Footer />
    </MotionConfig>
  );
}

import { hero } from '../data/content';
import Button from './ui/Button';
import Reveal, { stagger } from './ui/Reveal';

const LOAD_DELAY = 0.2;

export default function Hero() {
  const { image } = hero;
  const lineCount = hero.headingLines.length;

  return (
    <section
      id="home"
      aria-labelledby="hero-title"
      className="relative isolate flex min-h-[90vh] min-h-[90svh] items-center overflow-hidden bg-onyx"
    >
      {/* Background image with slow Ken Burns zoom */}
      <picture className="absolute inset-0 -z-20">
        <source media="(max-width: 767px)" srcSet={image.webpMobile} type="image/webp" />
        <source srcSet={image.webp} type="image/webp" />
        <img
          src={image.jpg}
          alt={image.alt}
          width={image.width}
          height={image.height}
          fetchpriority="high"
          decoding="async"
          className="h-full w-full origin-center animate-kenburns object-cover motion-reduce:animate-none"
        />
      </picture>

      {/* Legibility overlay + soft fade into the next section */}
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-hero-overlay" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-onyx/30 md:hidden" />
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 -z-10 h-32 bg-hero-fade opacity-90" />

      <div className="container-luxe pb-24 pt-28 md:pt-header">
        <div className="max-w-3xl">
          <Reveal as="p" onMount delay={LOAD_DELAY} className="eyebrow text-gold-light">
            {hero.eyebrow}
          </Reveal>

          <h1 id="hero-title" className="mt-6 text-h1 font-normal text-ivory">
            {hero.headingLines.map((line, i) => (
              <Reveal as="span" key={i} onMount delay={stagger(i + 1, LOAD_DELAY, 0.14)} className="block">
                {line.map((seg) =>
                  seg.accent ? (
                    <em key={seg.text} className="font-normal italic text-gold-light">
                      {seg.text}
                    </em>
                  ) : (
                    <span key={seg.text}>{seg.text}</span>
                  ),
                )}
              </Reveal>
            ))}
          </h1>

          <Reveal
            as="p"
            onMount
            delay={stagger(lineCount + 1, LOAD_DELAY, 0.14)}
            className="mt-8 max-w-xl text-body text-ivory/80 md:text-lg"
          >
            {hero.subheading}
          </Reveal>

          <Reveal
            onMount
            delay={stagger(lineCount + 2, LOAD_DELAY, 0.14)}
            className="mt-10 flex flex-col gap-4 xs:flex-row xs:flex-wrap"
          >
            <Button href={hero.primaryCta.href} variant="dark" arrow>
              {hero.primaryCta.label}
            </Button>
            <Button href={hero.secondaryCta.href} variant="outline-light">
              {hero.secondaryCta.label}
            </Button>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

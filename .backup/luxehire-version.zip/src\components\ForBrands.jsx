import { forBrands } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import FeatureCard from './ui/FeatureCard';
import Button from './ui/Button';
import Reveal, { stagger } from './ui/Reveal';

export default function ForBrands() {
  return (
    <section id="for-brands" aria-labelledby="for-brands-title" className="surface-glow section-pad bg-champagne">
      <div className="container-luxe">
        <SectionHeading
          id="for-brands-title"
          eyebrow={forBrands.eyebrow}
          title={forBrands.title}
          description={forBrands.description}
        />

        <div className="mx-auto mt-16 grid max-w-grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {forBrands.features.map((f, i) => (
            <FeatureCard key={f.title} {...f} delay={stagger(i)} />
          ))}
        </div>

        <Reveal className="mt-14 flex justify-center">
          <Button href={forBrands.cta.href} variant="gold" arrow>
            {forBrands.cta.label}
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

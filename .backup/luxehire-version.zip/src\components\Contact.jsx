import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Loader2, Mail, MapPin, Phone } from 'lucide-react';
import { contact } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import Button from './ui/Button';
import Reveal, { EASE_LUXE, stagger } from './ui/Reveal';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const INITIAL = { name: '', email: '', phone: '', subject: '', message: '', consent: false };

function validate(values) {
  const { errors } = contact.form;
  const out = {};
  if (!values.name.trim()) out.name = errors.name;
  if (!values.email.trim()) out.email = errors.email;
  else if (!EMAIL_RE.test(values.email.trim())) out.email = errors.emailInvalid;
  if (!values.message.trim()) out.message = errors.message;
  if (!values.consent) out.consent = errors.consent;
  return out;
}

/* ------------------------------------------------------------------ */

const IndiaFlag = () => (
  <svg aria-hidden="true" viewBox="0 0 30 20" className="h-3.5 w-5 rounded-[1px] shadow-sm">
    <rect width="30" height="20" fill="#FF9933" />
    <rect y="6.67" width="30" height="6.67" fill="#FFFFFF" />
    <rect y="13.33" width="30" height="6.67" fill="#138808" />
    <circle cx="15" cy="10" r="2.4" fill="none" stroke="#000080" strokeWidth=".6" />
  </svg>
);

function FieldError({ id, message }) {
  return (
    <AnimatePresence>
      {message && (
        <motion.p
          id={id}
          role="alert"
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          className="mt-2 text-xs font-normal text-red-800"
        >
          {message}
        </motion.p>
      )}
    </AnimatePresence>
  );
}

function Field({ id, label, error, required, children, helper }) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-xs font-medium uppercase tracking-widest text-ink/80">
        {label}
        {required && (
          <span aria-hidden="true" className="ml-1 text-gold-deep">
            *
          </span>
        )}
      </label>
      {children}
      {helper && (
        <p id={`${id}-helper`} className="mt-2 text-xs text-stone">
          {helper}
        </p>
      )}
      <FieldError id={`${id}-error`} message={error} />
    </div>
  );
}

/* ------------------------------------------------------------------ */

function DetailRow({ icon: Icon, children }) {
  return (
    <li className="flex gap-4">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-gold/60 text-gold">
        <Icon aria-hidden="true" strokeWidth={1.25} className="h-4 w-4" />
      </span>
      <span className="pt-2 text-body-sm text-stone">{children}</span>
    </li>
  );
}

function CompanyDetails() {
  const { details } = contact;
  const linkCls = 'transition-colors hover:text-gold-deep';

  return (
    <div className="h-full rounded-luxe border border-sand bg-white/70 p-8 shadow-card">
      <h3 className="text-card-title font-medium text-ink">{details.title}</h3>
      <div aria-hidden="true" className="mt-4 h-px w-10 bg-gold" />
      <ul className="mt-8 space-y-6">
        <DetailRow icon={Mail}>
          <a href={`mailto:${details.email}`} className={linkCls}>
            {details.email}
          </a>
        </DetailRow>
        {details.phones.map((p) => (
          <DetailRow key={p.tel} icon={Phone}>
            <a href={`tel:${p.tel}`} className={linkCls}>
              {p.display}
            </a>
          </DetailRow>
        ))}
        <DetailRow icon={MapPin}>
          <a
            href={details.mapUrl}
            target="_blank"
            rel="noopener noreferrer"
            className={`underline decoration-gold/60 underline-offset-4 ${linkCls}`}
          >
            {details.address}
          </a>
        </DetailRow>
      </ul>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function ContactForm() {
  const f = contact.form;
  const [values, setValues] = useState(INITIAL);
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState('idle'); // idle | sending | success | error

  const update = (key) => (e) => {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setValues((v) => ({ ...v, [key]: value }));
    if (errors[key]) setErrors((errs) => ({ ...errs, [key]: undefined }));
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length) {
      document.getElementById(`contact-${Object.keys(found)[0]}`)?.focus();
      return;
    }

    setStatus('sending');
    try {
      // Placeholder endpoint — wire to your backend / CRM. A dev mock lives in vite.config.js.
      const res = await fetch(f.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...values,
          phone: values.phone ? `${f.phonePrefix} ${values.phone}` : '',
        }),
      });
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      setStatus('success');
      setValues(INITIAL);
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  const describedBy = (key, extra) => [errors[key] && `contact-${key}-error`, extra].filter(Boolean).join(' ') || undefined;

  if (status === 'success') {
    return (
      <motion.div
        role="status"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: EASE_LUXE }}
        className="flex h-full flex-col items-center justify-center rounded-luxe border border-gold/50 bg-white/70 p-12 text-center shadow-card"
      >
        <CheckCircle2 aria-hidden="true" strokeWidth={1.25} className="h-12 w-12 text-gold" />
        <p className="mt-6 font-serif text-2xl text-ink">{f.success}</p>
      </motion.div>
    );
  }

  return (
    <form noValidate onSubmit={onSubmit} className="space-y-6" aria-label="Contact form">
      <div className="grid gap-6 sm:grid-cols-2">
        <Field id="contact-name" label={f.name} error={errors.name} required>
          <input
            id="contact-name"
            type="text"
            autoComplete="name"
            className="field"
            value={values.name}
            onChange={update('name')}
            aria-invalid={!!errors.name}
            aria-describedby={describedBy('name')}
            aria-required="true"
          />
        </Field>
        <Field id="contact-email" label={f.email} error={errors.email} required>
          <input
            id="contact-email"
            type="email"
            autoComplete="email"
            className="field"
            value={values.email}
            onChange={update('email')}
            aria-invalid={!!errors.email}
            aria-describedby={describedBy('email')}
            aria-required="true"
          />
        </Field>
      </div>

      <Field id="contact-phone" label={f.phone} helper={f.phoneHelper}>
        <div className="flex">
          <span className="inline-flex items-center gap-2 rounded-l-luxe border border-r-0 border-sand bg-champagne/70 px-3 text-body-sm font-normal text-ink">
            <IndiaFlag />
            {f.phonePrefix}
          </span>
          <input
            id="contact-phone"
            type="tel"
            inputMode="tel"
            autoComplete="tel-national"
            className="field rounded-l-none"
            value={values.phone}
            onChange={update('phone')}
            aria-describedby="contact-phone-helper"
          />
        </div>
      </Field>

      <Field id="contact-subject" label={f.subject}>
        <input
          id="contact-subject"
          type="text"
          className="field"
          value={values.subject}
          onChange={update('subject')}
        />
      </Field>

      <Field id="contact-message" label={f.message} error={errors.message} required>
        <textarea
          id="contact-message"
          rows={5}
          className="field resize-y"
          value={values.message}
          onChange={update('message')}
          aria-invalid={!!errors.message}
          aria-describedby={describedBy('message')}
          aria-required="true"
        />
      </Field>

      <div>
        <label htmlFor="contact-consent" className="flex cursor-pointer items-start gap-3">
          <input
            id="contact-consent"
            type="checkbox"
            checked={values.consent}
            onChange={update('consent')}
            aria-invalid={!!errors.consent}
            aria-describedby={describedBy('consent')}
            aria-required="true"
            className="mt-1 h-4 w-4 shrink-0 cursor-pointer rounded-[1px] border-sand accent-bronze"
          />
          <span className="text-sm text-stone">
            {f.consentBefore}
            <a
              href={f.consentLink.href}
              className="text-gold-deep underline decoration-gold/60 underline-offset-4 hover:text-ink"
            >
              {f.consentLink.label}
            </a>
            {f.consentAfter}
          </span>
        </label>
        <FieldError id="contact-consent-error" message={errors.consent} />
      </div>

      <Button type="submit" variant="gold" fullWidth disabled={status === 'sending'} aria-busy={status === 'sending'}>
        {status === 'sending' ? (
          <span className="inline-flex items-center gap-2">
            <Loader2 aria-hidden="true" strokeWidth={1.5} className="h-4 w-4 animate-spin" />
            {f.sending}
          </span>
        ) : (
          f.submit
        )}
      </Button>

      {status === 'error' && (
        <p role="alert" className="text-center text-sm text-red-800">
          {f.failure}
        </p>
      )}
    </form>
  );
}

/* ------------------------------------------------------------------ */

export default function Contact() {
  return (
    <section id="contact" aria-labelledby="contact-title" className="surface-glow section-pad bg-ivory">
      <div className="container-luxe">
        <SectionHeading
          id="contact-title"
          eyebrow={contact.eyebrow}
          title={contact.title}
          description={contact.description}
        />

        <div className="mx-auto mt-16 grid max-w-grid gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-12">
          <Reveal delay={stagger(0)}>
            <CompanyDetails />
          </Reveal>
          <Reveal delay={stagger(1)}>
            <ContactForm />
          </Reveal>
        </div>
      </div>
    </section>
  );
}

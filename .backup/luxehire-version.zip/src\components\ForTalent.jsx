import { forTalent } from '../data/content';
import SectionHeading from './ui/SectionHeading';
import FeatureCard from './ui/FeatureCard';
import Button from './ui/Button';
import Reveal, { stagger } from './ui/Reveal';

export default function ForTalent() {
  return (
    <section id="for-talent" aria-labelledby="for-talent-title" className="surface-glow section-pad bg-ivory">
      <div className="container-luxe">
        <SectionHeading
          id="for-talent-title"
          eyebrow={forTalent.eyebrow}
          title={forTalent.title}
          description={forTalent.description}
        />

        <div className="mx-auto mt-16 grid max-w-grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {forTalent.features.map((f, i) => (
            <FeatureCard key={f.title} {...f} delay={stagger(i)} />
          ))}
        </div>

        <Reveal className="mt-14 flex justify-center">
          <Button href={forTalent.cta.href} variant="gold" arrow>
            {forTalent.cta.label}
          </Button>
        </Reveal>
      </div>
    </section>
  );
}

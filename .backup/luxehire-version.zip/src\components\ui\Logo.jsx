import { brand } from '../../data/content';

/** "Luxe" in gold italic + "Hire" in regular Playfair. */
export default function Logo({ tone = 'light', className = '' }) {
  return (
    <a
      href="#home"
      aria-label={`${brand.name} — back to top`}
      className={`font-serif text-2xl tracking-tight ${className}`}
    >
      <span className="italic text-gold-light">{brand.logoItalic}</span>
      <span className={tone === 'light' ? 'text-ivory' : 'text-ink'}>{brand.logoRegular}</span>
    </a>
  );
}

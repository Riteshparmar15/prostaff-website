import { useEffect, useRef, useState } from 'react';
import { animate, useInView } from 'framer-motion';
import { stats } from '../data/content';
import Reveal, { stagger } from './ui/Reveal';
import useReducedMotion from '../hooks/useReducedMotion';

const COUNT_DURATION = 1.6;

function CountUp({ value, suffix }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  const reduced = useReducedMotion();
  const [display, setDisplay] = useState(reduced ? value : 0);

  useEffect(() => {
    if (reduced) {
      setDisplay(value);
      return undefined;
    }
    if (!inView) return undefined;
    const controls = animate(0, value, {
      duration: COUNT_DURATION,
      ease: 'easeOut',
      onUpdate: (v) => setDisplay(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, reduced, value]);

  return (
    <span ref={ref} className="tabular-nums">
      {/* Screen readers get the final figure, not every intermediate frame */}
      <span aria-hidden="true">
        {display}
        {suffix}
      </span>
      <span className="sr-only">
        {value}
        {suffix}
      </span>
    </span>
  );
}

export default function Stats() {
  return (
    <section aria-label="LuxeHire in numbers" className="surface-grain bg-midnight py-16 md:py-20">
      <div className="container-luxe">
        <dl className="grid grid-cols-2 gap-y-12 lg:grid-cols-4">
          {stats.map((stat, i) => (
            <Reveal
              key={stat.label}
              delay={stagger(i)}
              className={[
                'flex flex-col-reverse items-center px-4 text-center',
                // Thin gold dividers between columns on desktop; between pairs on mobile
                i % 2 === 1 ? 'border-l border-gold/25' : '',
                i > 0 ? 'lg:border-l lg:border-gold/25' : 'lg:border-l-0',
              ].join(' ')}
            >
              <dt className="mt-4 text-eyebrow font-medium uppercase tracking-eyebrow text-mist">{stat.label}</dt>
              <dd className="font-serif text-stat font-normal text-gold-light">
                <CountUp value={stat.value} suffix={stat.suffix} />
              </dd>
            </Reveal>
          ))}
        </dl>
      </div>
    </section>
  );
}
